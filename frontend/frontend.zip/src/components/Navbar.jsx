import { Link, useNavigate } from "react-router-dom";
import { FaShoppingCart, FaUserCircle, FaHeart } from "react-icons/fa";
import { useSelector, useDispatch } from "react-redux";
import { logout } from "../features/auth/authSlice";

// Navbar component - main navigation bar for customer pages
// Displays app logo, navigation links, logout button, profile icon, favorites link,
// and cart icon with item count
function Navbar() {
  // Get all items from Redux cart state
  const items = useSelector((state) => state.cart.items);

  // Calculate total number of items in cart
  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);

  const dispatch = useDispatch();
  const navigate = useNavigate();

  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">
        {/* App branding and home link */}
        <Link to="/customer" className="text-2xl font-bold text-orange-500">
          🍔 Foodie
        </Link>

        {/* Navigation links and user actions */}
        <div className="flex items-center gap-6">
          {/* Recommendations */}
          <Link
            to="/customer/recommendations"
            className="text-gray-700 hover:text-orange-500 font-medium"
          >
            Recommendations
          </Link>

          {/* Preferences */}
          <Link
            to="/customer/preferences"
            className="text-gray-700 hover:text-orange-500 font-medium"
          >
            Preferences
          </Link>

          {/* Orders */}
          <Link
            to="/customer/my-orders"
            className="text-gray-700 hover:text-orange-500 font-medium"
          >
            My Orders
          </Link>

          {/* Favorite Restaurants */}
          <Link
            to="/customer/favorite-restaurants"
            className="flex items-center gap-2 text-gray-700 hover:text-orange-500 font-medium"
          >
            <FaHeart className="text-lg" />
            Favorites
          </Link>

          {/* Logout */}
          <button
            onClick={() => {
              dispatch(logout());
              navigate("/", { replace: true });
            }}
            className="text-gray-700 hover:text-orange-500 font-medium cursor-pointer active:scale-95 active:opacity-90"
          >
            Logout
          </button>

          {/* Profile */}
          <Link
            to="/customer/profile"
            className="text-gray-700 hover:text-orange-500"
            title="Profile"
          >
            <FaUserCircle className="text-2xl" />
          </Link>

          {/* Cart */}
          <Link to="/customer/cart" className="relative" title="Cart">
            <FaShoppingCart className="text-2xl text-gray-700 hover:text-orange-500" />

            {totalItems > 0 && (
              <span className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {totalItems}
              </span>
            )}
          </Link>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
