import {
  Link,
  Outlet,
  useLocation,
  useParams,
  useNavigate,
} from "react-router-dom";
import {
  FaStore,
  FaUtensils,
  FaClipboardList,
  FaSignOutAlt,
} from "react-icons/fa";
import { useDispatch } from "react-redux";
import { logout } from "../features/auth/authSlice";

function OwnerLayout() {
  // Get the current URL location (used to highlight the active tab)
  const location = useLocation();

  // Get restaurantId from the URL
  const { restaurantId } = useParams();

  // Redux dispatch function
  const dispatch = useDispatch();

  // Used for programmatic navigation
  const navigate = useNavigate();

  // Navigation paths
  const dashboardPath = `/owner/restaurants/${restaurantId}/dashboard`;
  const menuPath = `/owner/restaurants/${restaurantId}/menu`;
  const ordersPath = `/owner/restaurants/${restaurantId}/orders`;

  // Returns different styles for active and inactive navigation links
  const linkStyle = (path) =>
    `flex items-center gap-2 px-4 py-2 rounded-lg transition ${
      location.pathname === path
        ? "bg-orange-500 text-white"
        : "text-gray-700 hover:bg-orange-100 hover:text-orange-500"
    }`;

  return (
    <div className="min-h-screen bg-orange-50">
      {/* Top Navigation Bar */}
      <nav className="bg-white shadow-md border-b">
        <div className="max-w-7xl mx-auto flex items-center justify-between px-8 py-4">
          {/* Logo / Home */}
          <Link
            to="/owner"
            className="text-3xl font-bold text-orange-500 flex items-center gap-2"
          >
            🍽 Owner Panel
          </Link>

          {/* Navigation Links */}
          <div className="flex items-center gap-4">
            {/* Dashboard */}
            <Link to={dashboardPath} className={linkStyle(dashboardPath)}>
              <FaStore />
              Dashboard
            </Link>

            {/* Menu */}
            <Link to={menuPath} className={linkStyle(menuPath)}>
              <FaUtensils />
              Menu
            </Link>

            {/* Orders */}
            <Link to={ordersPath} className={linkStyle(ordersPath)}>
              <FaClipboardList />
              Orders
            </Link>

            {/* Logout Button */}
            <button
              onClick={() => {
                // Clear authentication data from Redux
                dispatch(logout());

                // Redirect user to login/home page
                navigate("/", { replace: true });
              }}
              className="flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition cursor-pointer active:scale-95 active:opacity-90"
            >
              <FaSignOutAlt />
              Logout
            </button>
          </div>
        </div>
      </nav>

      {/* Child pages (Dashboard, Menu, Orders) are rendered here */}
      <main className="max-w-7xl mx-auto py-8 px-6">
        <Outlet />
      </main>
    </div>
  );
}

export default OwnerLayout;
